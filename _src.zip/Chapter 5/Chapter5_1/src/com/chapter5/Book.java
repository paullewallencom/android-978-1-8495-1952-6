package com.chapter5;

public class Book {
	public static final String[] BOOK_NAMES = { "Book Name 1", "Book Name 2",
			"Book Name 3", "Book Name 4", "Book Name 5", "Book Name 6",
			"Book Name 7", "Book Name 8" };
	
	public static final String[] WRITER_NAMES = { "Writer of Book 1", "Writer of Book 2",
		"Writer of Book 3", "Writer of Book 4", "Writer of Book 5", "Writer of Book 6",
		"Writer of Book 7", "Writer of Book 8" };
}
